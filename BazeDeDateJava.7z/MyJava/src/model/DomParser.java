package model;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DomParser {
   public void ImplementDomParser(){
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    try {
		DocumentBuilder builder=  factory.newDocumentBuilder();
		Document doc = builder.parse("exemplu.xml");
		doc.getDocumentElement().normalize();
		
		//the root node
		Element root=doc.getDocumentElement();
		System.out.println(root.getNodeName());
		
		//Get all the elevi
		
		NodeList nList=doc.getElementsByTagName("elev");
		System.out.println("-------------------");
		
		for(int temp=0; temp < nList.getLength(); temp++){
			Node node=nList.item(temp);
			System.out.println(" ");
			
			if(node.getNodeType()==node.ELEMENT_NODE){
				//print each elev detail
				
				Element vElement=(Element) node;
				System.out.println("Elev id :"    + vElement.getAttribute("id"));
				System.out.println("Nume: "  + vElement.getElementsByTagName("nume").item(0).getTextContent());
				System.out.println("Prenume: "  + vElement.getElementsByTagName("prenume").item(0).getTextContent());
				System.out.println("Varsta: "  + vElement.getElementsByTagName("varsta").item(0).getTextContent());
			}
		}
		
	
	} catch (ParserConfigurationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SAXException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	

	     
}
}

