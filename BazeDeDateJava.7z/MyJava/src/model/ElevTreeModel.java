package model;

import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;

public class ElevTreeModel extends DefaultTreeModel {

	private Vector<Elev> elevi;

	public ElevTreeModel(DefaultMutableTreeNode root, Vector<Elev> elevi) {
		super(root, true);

		this.elevi = elevi;
		for (Elev elev : elevi) {
			DefaultMutableTreeNode node = getNodeFrom(elev);
			root.add(node);
		}

	}

	private DefaultMutableTreeNode getNodeFrom(Elev elev) {
		DefaultMutableTreeNode node = new DefaultMutableTreeNode();
		node.setAllowsChildren(true);
		node.setUserObject(elev);
		DefaultMutableTreeNode nodeName = new DefaultMutableTreeNode();
		nodeName.setAllowsChildren(false);
		nodeName.setUserObject("Nume : " + elev.getNume());
		DefaultMutableTreeNode nodePrenume = new DefaultMutableTreeNode();
		nodePrenume.setAllowsChildren(false);
		nodePrenume.setUserObject("Preume : " + elev.getPrenume());
		DefaultMutableTreeNode nodeVarsta = new DefaultMutableTreeNode();
		nodeVarsta.setAllowsChildren(false);
		nodeVarsta.setUserObject("Varsta : " + elev.getVarsta());
		node.add(nodeName);
		node.add(nodePrenume);
		node.add(nodeVarsta);
		return node;
	}

	public void insert(Elev elev) {
		elevi.add(elev);
		DefaultMutableTreeNode node = getNodeFrom(elev);
		((DefaultMutableTreeNode) root).add(node);
		reload();
	}

//	public void reload() {
  //      reload(root);
    //}

	public void removeNode(Elev e) {
		int index = elevi.indexOf(e);
		if (index >= 0) {
			((DefaultMutableTreeNode) root).remove(index);
			elevi.remove(index);
			reload();
		}
	}

	public void updateNode(Elev e) {
		int index = elevi.indexOf(e);
		if (index >= 0) {
			DefaultMutableTreeNode node = getNodeFrom(e);
			((DefaultMutableTreeNode) root).remove(index);
			((DefaultMutableTreeNode) root).insert(node, index);
			reload();
		}
	}

}
