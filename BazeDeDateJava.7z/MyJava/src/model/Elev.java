package model;

public class Elev {
      private int varsta;
      private int id;
	  private String nume;
	  private String prenume;
	  
	 public int getVarsta(){return varsta;}
	 public int getId(){return id;}
	 public String getNume(){return nume;}
	 public String getPrenume(){return prenume;}
	 
	 public void setVarsta(int varsta){this.varsta=varsta; }
	 public void setId(int id){this.id=id;}
	 public void setNume(String nume){this.nume=nume;}
	 public void setPrenume(String prenume){this.prenume=prenume;}
	 
	  @Override
//	public String toString() {
//		// TODO Auto-generated method stub
//		return " Id: "+ id+" nume: "+nume+" prenume: "+ prenume+" varsta: "+varsta;
//	}
	  public String toString() {
		  return "Elev (id : "+id+")";
	  }
	 
}
