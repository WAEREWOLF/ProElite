package model;

import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class ElevTabelModel extends DefaultTableModel
{
	private Vector<Elev> elevi;
	

	
	
    public ElevTabelModel(Vector <Elev>elevi)
    {
    	super();
    	this.elevi = elevi;
    	
    }
    
    public void setElevi(Vector<Elev> elevi) {
    	this.elevi = elevi;
    	fireTableDataChanged();
    }
    
    @Override
    public int getColumnCount() {
    	return 4;
    }
    
    @Override
    public int getRowCount() {
    	if(elevi == null) return 0;
    	return elevi.size();
    }
    
    @Override
    public Class<?> getColumnClass(int columnIndex) {
    	if(columnIndex == 0 || columnIndex == 3)
    		return Integer.class;
    	return String.class;
    }
    
    @Override
    public String getColumnName(int column) {
    	switch(column){
    		case 0: return "Id";
    		case 1: return "Nume";
    		case 2: return "Prenume";
    		case 3: return "Varsta";
    	}
    	return "";
    }
    
    @Override
    public Object getValueAt(int row, int column) {
    	if (row >=0 && row < elevi.size()){
    		Elev elev = elevi.get(row);
    		switch(column){
	    		case 0: return elev.getId();
	    		case 1: return elev.getNume();
	    		case 2: return elev.getPrenume();
	    		case 3: return elev.getVarsta();
	    		default: return null;
    		}
    	}
    	
    	return null;
    }
    
    @Override
    public boolean isCellEditable(int row, int column) {
    	// TODO Auto-generated method stub
    	return false;
    }
    
    public Elev getElevFromIndex(int index){
    	if (index >=0 && index < elevi.size()){
    		return elevi.get(index);
    	}
    	return null;
    }
    
    public void insert(Elev elev){
    	elevi.add(elev);
    	fireTableDataChanged();
    }
    
    public void delete (int index){
    	if(index>=0 && index<elevi.size())
    		{
    		 elevi.remove(index);
    		 fireTableDataChanged();
    		}
    	
    }
      
    
}
    
	
 
	

