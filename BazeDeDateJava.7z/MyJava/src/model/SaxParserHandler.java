package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserHandler extends DefaultHandler
{
	private boolean belevi=false;
	private boolean bprenume=false;
	private boolean blnume=false;
	private boolean bvarsta=false;
	private Elev elev;
	private Vector<Elev> elevi = new Vector<Elev>();
	
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		// TODO Auto-generated method stub
		super.startElement(uri, localName, qName, attributes);
		if(qName.equalsIgnoreCase("elev")){
			belevi=true;
			elev=new Elev();
			elev.setId(Integer.parseInt(attributes.getValue("id")));
		}
		if (qName.equalsIgnoreCase("nume")) {
			blnume = true;
		}

		if (qName.equalsIgnoreCase("prenume")) {
			bprenume = true;
		}

		if (qName.equalsIgnoreCase("varsta")) {
			bvarsta = true;
		}
	} 
	
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		// TODO Auto-generated method stub
		super.endElement(uri, localName, qName);
		if(qName.equalsIgnoreCase("elev")){
//			System.out.println(elev.toString());
			belevi = false;
			elevi.add(elev);
			elev = null;
		}
		if (qName.equalsIgnoreCase("nume")) {
			blnume = false;
		}

		if (qName.equalsIgnoreCase("prenume")) {
			bprenume = false;
		}

		if (qName.equalsIgnoreCase("varsta")) {
			bvarsta = false;
		}
		
	}
	
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		// TODO Auto-generated method stub
		super.characters(ch, start, length);
		String val = new String(ch, start, length);
		if (blnume) {
			elev.setNume(val);
		} else if (bprenume) {
			elev.setPrenume(val);
		} else	if (bvarsta) {
			elev.setVarsta(Integer.parseInt(val));
		}
	}
	
	public Vector<Elev> getElevi(){
		return elevi;
	}
	
	
}
