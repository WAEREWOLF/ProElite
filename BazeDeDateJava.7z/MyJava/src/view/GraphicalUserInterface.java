package view;

import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;

import model.Elev;


public class GraphicalUserInterface extends JFrame{
	JList list;
	JFrame frame;
	GraphicalUserInterface(String windowView, Vector<Elev>vectorElev)
	{
		
				
	    frame=new JFrame("Elevi");	
		JPanel panel= new JPanel();
		
	
		list=new JList(vectorElev);
			
		panel.add(list);
		frame.add(panel);
		
		frame.setSize(400, 400);
		frame.setVisible(true);
		
	}

}
