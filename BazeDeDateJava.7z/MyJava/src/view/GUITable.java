package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import controller.ConnectionDB;
import model.Elev;
import model.ElevTabelModel;

public class GUITable extends JFrame {

	JTable table;
	Elev elev;
	Vector<Elev> elevi;
	ConnectionDB test;
	
	
	GUITable(String windowName) {
		super(windowName);
		test = new ConnectionDB();
		
		this.elevi = test.getElevi();
		createView();
		}
	
	GUITable(String windowName, Vector<Elev> _elevi) {
		super(windowName);
		this.elevi = _elevi;
		createView();
	}
			
	private void createView() {
	//	ButtonsAction ba = new ButtonsAction();
		JPanel panel = new JPanel();
		panel.setLayout(null);
		ElevTabelModel model = new ElevTabelModel(elevi);
		table = new JTable(model);
		JScrollPane sp = new JScrollPane(table);
		sp.setBounds(30, 40, 400, 150);
		panel.add(sp);
		add(panel);
		
		JButton buttonDelete = new JButton("Delete");
		buttonDelete.setBounds(350, 300, 100, 30);
		panel.add(buttonDelete);
	    buttonDelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				int index = table.getSelectedRow();
				Elev elev = model.getElevFromIndex(index);
				if (elev != null) {
					if (test != null) {
						if (test.deleteElev(elev.getId())) {
							model.delete(index);
						}
					} else {
						model.delete(index);
					}
				
				}
				else {
					JOptionPane.showMessageDialog(null, "Nothing is selected!");

				}
				
			}
		});
		
	     
		JButton buttonInsert = new JButton("Insert");
		buttonInsert.setBounds(200, 300, 100, 30);
		panel.add(buttonInsert);
		
	//	buttonInsert.addActionListener(ba);
		buttonInsert.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JButton btn = (JButton)e.getSource();
				if(btn.getText().equalsIgnoreCase("insert"))
					new UpdateInterfaceTable("Elev nou", GUITable.this,null);
				
			}
		});
		
		
		
		JButton buttonCancel = new JButton("Cancel");
		buttonCancel.setBounds(200, 370, 100, 30);
		panel.add(buttonCancel);
		buttonCancel.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
				
			}
		});
	    
		
		JButton buttonUpdate = new JButton("Update");
		buttonUpdate.setBounds(40, 300, 100, 30);
		panel.add(buttonUpdate);
		
		buttonUpdate.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int index = table.getSelectedRow();
				Elev elev = model.getElevFromIndex(index);

				new UpdateInterfaceTable("Elev selectat", GUITable.this, elev);

			}
		});
		
		JButton buttonShowTree = new JButton("Show Tree");
		buttonShowTree.setBounds(350, 370, 100, 30);
		panel.add(buttonShowTree);
		buttonShowTree.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				 new GUITree("Tree with elevi",elevi);
				
			}
		});
		
		JButton buttonGetElevi = new JButton("Get Elevi");
		buttonGetElevi.setBounds(40, 370, 100, 30);
		panel.add(buttonGetElevi);
		buttonGetElevi.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if (test != null) {
					GUITable.this.elevi = test.getElevi();
				}
				model.setElevi(GUITable.this.elevi);	
			}
		});
	    
		
		pack();
		setSize(500, 500);
		
		setVisible(true);
	}

	public void refreshTable() {
		((DefaultTableModel) table.getModel()).fireTableDataChanged();
	}

	public void insertElev(Elev elev) {
		ElevTabelModel model = (ElevTabelModel) table.getModel();
	
		if(test != null) {
			if (test.insertEleviWithPrepareStatement(elev)) {
				model.insert(elev);
			}
		} else {
			model.insert(elev);
		}
	}
	
	public void updateElev(Elev elev) {
		
		if(test != null) {
			if (test.updateEleviWithPrepareStatement(elev)) {
				refreshTable();
			}
		} else {
			refreshTable();
		}
	}
	
}

