
package view;

import java.util.Vector;

import model.Elev;

public class Main {

	public static void main(String args[]) throws Exception {

		Vector<Elev> elevi = null;
//  try{
//	  SAXParserFactory factory =SAXParserFactory.newInstance();
//	  SAXParser saxParser = factory.newSAXParser();
//	  SaxParserHandler sph = new SaxParserHandler();
//	  saxParser.parse("exemplu.xml", sph);
//	  elevi = sph.getElevi();
//			
//     }catch(Exception e ){
//	  e.printStackTrace();
//     }

		new GUITable("Fereastra cu elevi");

	}
}
