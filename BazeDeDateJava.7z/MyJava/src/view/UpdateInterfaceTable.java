package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Elev;

public class UpdateInterfaceTable extends JFrame {

	JTextField id;
	JTextField nume;
	JTextField prenume;
	JTextField varsta;

	JButton buttonUpdate;

	Elev elev;

	public UpdateInterfaceTable(String nume1, GUITable parent, Elev elev) {
		super(nume1);
		JPanel panel = new JPanel();
		panel.setLayout(null);
		this.elev = elev;
		id = new JTextField();
		nume = new JTextField();
		prenume = new JTextField();
		varsta = new JTextField();
		if (elev != null) {
			id.setText("" + elev.getId());
			nume.setText(elev.getNume());
			prenume.setText(elev.getPrenume());
			varsta.setText(""+elev.getVarsta());
		}

		JLabel IdLabel = new JLabel("Id:  ");
		JLabel NumeLabel = new JLabel("Nume:  ");
		JLabel PrenumeLabel = new JLabel("Prenume:  ");
		JLabel VarstaLabel = new JLabel("Varsta:  ");

		IdLabel.setBounds(10, 10, 100, 30);
		NumeLabel.setBounds(10, 50, 100, 30);
		PrenumeLabel.setBounds(10, 90, 100, 30);
		VarstaLabel.setBounds(10, 130, 100, 30);

		id.setBounds(120, 10, 100, 30);
		nume.setBounds(120, 50, 100, 30);
		prenume.setBounds(120, 90, 100, 30);
		varsta.setBounds(120, 130, 100, 30);

		if(elev != null)
			buttonUpdate = new JButton("Update");
		else 
			buttonUpdate = new JButton("Insert");
		buttonUpdate.setBounds(120, 200, 100, 30);

		JButton buttonCancel = new JButton("Cancel");
		buttonCancel.setBounds(10, 200, 100, 30);
		
		
		panel.add(IdLabel);
		panel.add(id);
		panel.add(NumeLabel);
		panel.add(nume);
		panel.add(PrenumeLabel);
		panel.add(prenume);
		panel.add(VarstaLabel);
		panel.add(varsta);
		panel.add(buttonUpdate);
		panel.add(buttonCancel);
		
		add(panel);

		pack();
		setSize(350, 350);
		setVisible(true);

		buttonCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				UpdateInterfaceTable.this.dispose();
			}
		});
		
		buttonUpdate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				if(elev == null){
					Elev el = new Elev();
					el.setId(Integer.parseInt(id.getText()));
					el.setVarsta(Integer.parseInt(varsta.getText()));
					el.setNume(nume.getText());
					el.setPrenume(prenume.getText());
					parent.insertElev(el);
				} else {
					elev.setId(Integer.parseInt(id.getText()));
					elev.setVarsta(Integer.parseInt(varsta.getText()));
					elev.setNume(nume.getText());
					elev.setPrenume(prenume.getText());
					parent.updateElev(elev);
					
				}
				UpdateInterfaceTable.this.dispose();

			}

		});
			
	}


}
