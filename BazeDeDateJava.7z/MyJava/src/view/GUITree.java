package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import controller.ConnectionDB;
import model.Elev;
import model.ElevTreeModel;

public class GUITree {

	Elev elev;
	Vector<Elev> elevi;
	JTree tree;
	ConnectionDB test;

	GUITree(String windowName, Vector<Elev> elv) {
		elevi = new Vector<Elev>();
		elevi.addAll(elv);
		DefaultMutableTreeNode root = new DefaultMutableTreeNode("Elevi", true);
		ElevTreeModel model = new ElevTreeModel(root, elevi);
		
		test = new ConnectionDB();
		this.elevi = test.getElevi();
		
		// create the tree by passing in the root node
		tree = new JTree(model);

		JFrame f = new JFrame();
		f.setDefaultCloseOperation(f.DISPOSE_ON_CLOSE);
		f.setTitle("JTree Elevi");
		f.pack();
		f.setBounds(500, 0, 520, 400);

		JScrollPane jScrollPane = new JScrollPane(tree);

		jScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		jScrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		jScrollPane.setBounds(0, 0, 300, 200);
		f.add(jScrollPane);

		f.setLayout(null);
		f.setVisible(true);

		// buttons
		JButton buttonDelete = new JButton("Delete");
		buttonDelete.setBounds(120, 250, 100, 30);

		f.add(buttonDelete);
		buttonDelete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				ElevTreeModel model = (ElevTreeModel) tree.getModel();
								
				TreePath selectedPath = tree.getSelectionPath();
				if(selectedPath == null) {
					JOptionPane.showMessageDialog(null, "Nothing is selected!");
				} else {
					try {
						TreeNode selectedNode = (TreeNode) selectedPath.getLastPathComponent();
						if (selectedNode == model.getRoot()) {
							System.out.println("Select an elev node!");
							return;
						}
						if (selectedNode.isLeaf()) {
							selectedNode = selectedNode.getParent();
						}
						Elev el = (Elev) ((DefaultMutableTreeNode) selectedNode).getUserObject();
						if(el != null) {
							if(test != null) {
								if(test.deleteElev(el.getId()))
									model.removeNode(el);
							}
							else {
								model.removeNode(el);
							}
						}
					 					
					} catch (Exception ex) {
						ex.printStackTrace();
				      }
				}
		  }

		});

		JButton buttonUpdate = new JButton("Update");
		buttonUpdate.setBounds(5, 250, 100, 30);
		f.add(buttonUpdate);
		buttonUpdate.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				TreeNode selectedNode = (TreeNode) tree.getSelectionPath().getLastPathComponent();
				if (selectedNode == model.getRoot()) {
					System.out.println("Select an elev node!");
					return;
				}
				if (selectedNode.isLeaf()) {
					selectedNode = selectedNode.getParent();
				}
				Elev el = (Elev) ((DefaultMutableTreeNode) selectedNode).getUserObject();
				new UpdateInterfaceTree("Modificare Elev", GUITree.this, el);
			}
		});
		JButton buttonInsert = new JButton("Insert");
		buttonInsert.setBounds(235, 250, 100, 30);
		f.add(buttonInsert);
		buttonInsert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				new UpdateInterfaceTree("Elev nou", GUITree.this, null);
			}
		});

		JButton buttonCancel = new JButton("Cancel");
		buttonCancel.setBounds(350, 250, 100, 30);
		f.add(buttonCancel);
		buttonCancel.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				f.setVisible(false);
				f.dispose();
			}
		});

	}
	
	public void insertElev(Elev elev) {
				
		if(test != null) {
			if (test.insertEleviWithPrepareStatement(elev)) {
				((ElevTreeModel) tree.getModel()).insert(elev);
			}
		} else {
			((ElevTreeModel) tree.getModel()).insert(elev);
		}

	}

	public void updateElev(Elev elev) {

		if(test != null) {
			if (test.updateEleviWithPrepareStatement(elev)) {
				((ElevTreeModel) tree.getModel()).updateNode(elev);
			}
		} else {
			((ElevTreeModel) tree.getModel()).updateNode(elev);
		}
	}
	
	}

