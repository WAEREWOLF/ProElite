package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import model.Elev;

public class ConnectionDB {
	private Connection conn = null;

	public ConnectionDB() {
		try {
			Class.forName("org.mariadb.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mariadb://localhost:3306/Elevi", "root", "gaga");
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}
	

	public Vector<Elev> getElevi() {
		if (conn == null)
			return null;
		try {
			Statement stmt = conn.createStatement();
			String sql = "SELECT id, nume, prenume, varsta FROM Elevi";
			ResultSet rs = stmt.executeQuery(sql);
			Vector<Elev> elevi=new Vector<Elev>();
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("nume");
				String prenume = rs.getString("prenume");
				int age = rs.getInt("varsta");
				
				Elev elev=new Elev();
				elev.setId(id);
				elev.setNume(name);
				elev.setPrenume(prenume);
				elev.setVarsta(age);
				elevi.add(elev);
				
			}
			// STEP 6: Clean-up environment
			rs.close();
			stmt.close();
			return elevi;
		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
		return null;

	}

	public void insertElevi(Elev elev) {
		if (conn == null)
			return;
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			String sql = "INSERT INTO Elevi VALUES (3,'Ion','Admin',20)";
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se) {
			} // do nothing
		}
	}
	
	public void updateElev(Elev elev) {
		if (conn == null)
			return;
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			String sql ="UPDATE Elevi SET name = 'ionel' WHERE id = 1";
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se) {
			} // do nothing
		}
	}
	
	public boolean updateEleviWithPrepareStatement(Elev elev) {
		if (conn == null)
			return false;
		PreparedStatement stmt = null;
		try {
			String sql ="UPDATE Elevi SET id = ?,nume = ?, prenume = ?, varsta = ?  WHERE id = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, elev.getId());
			stmt.setString(2, elev.getNume());
			stmt.setString(3, elev.getPrenume());
			stmt.setInt(4, elev.getVarsta());
			stmt.setInt(5, elev.getId());
			
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se) {
			} // do nothing
		}
		return true;
	}
	
	public boolean insertEleviWithPrepareStatement(Elev elev) {
		if (conn == null)
			return false;
		PreparedStatement stmt = null;
		try {
			String sql ="INSERT INTO elevi VALUES (?, ?, ?, ?)";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, elev.getId());
			stmt.setString(2, elev.getNume());
			stmt.setString(3, elev.getPrenume());
			stmt.setInt(4, elev.getVarsta());
			
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se) {
			} // do nothing
		}
		return true;
	}
	
	public boolean deleteElev(int id) {
		if (conn == null)
			return false;
		Statement stmt = null;
		try {
			stmt = conn.createStatement();
			String sql ="DELETE FROM Elevi WHERE id = "+id;
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} finally {
			// finally block used to close resources
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se) {
			} // do nothing
		}
		return true;
	}
	
	public boolean deleteEleviWithPs(int id) {
		if(conn==null)
			return false;
		PreparedStatement stmt=null;
		try {
			String sql="DELETE FROM Elevi WHERE id = ?";
			stmt =conn.prepareStatement(sql);
			stmt.setInt(1,id);
			stmt.executeUpdate(sql);
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			try {
				if (stmt != null)
					stmt.close();
			
			}catch (SQLException se) {
			}
		}
		return true;
	}

	public void closeConnection() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			conn = null;
		}
	}

}
